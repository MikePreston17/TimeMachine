﻿namespace TimeMachine
{
    public enum ServiceStatus
    {
        Running,
        Restarting,
        Stopping,
        Stopped,
    }
}
